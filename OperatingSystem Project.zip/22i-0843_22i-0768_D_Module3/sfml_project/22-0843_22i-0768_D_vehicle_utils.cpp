#include "vehicle_utils.h"
float simulationTime = 0.0f;  // Define simulationTime here
sf::Clock sfClock;  



// Function to generate vehicle number plates
std::string generateNumberPlate(int id) {
    int randomMultiplier = rand() % 100 + 1;  // Random multiplier between 1 and 100
    int uniqueId = id * randomMultiplier;

    std::stringstream ss;
    ss << "CAR-" << std::setfill('0') << std::setw(6) << uniqueId;
    return ss.str();
}

void updateSimulationTime(float deltaTime) {
    simulationTime += deltaTime;  // Increment simulation time by deltaTime each frame
}



std::string getMockDateTimeString(float simulationTime) {
    int hour = (int)simulationTime / 60;
    int minute = (int)simulationTime % 60;
    return std::to_string(hour) + ":" + (minute < 10 ? "0" : "") + std::to_string(minute);
}

// Check if the vehicle is within peak hours
bool isPeakHour(int simulationTime) {
    int hour = (int)simulationTime / 60;
    int minute = (int)simulationTime % 60;

    // Define peak hours for heavy vehicles (7:00am - 9:30am, 4:30pm - 8:30pm)
    if ((hour == 7 && minute >= 0) || (hour > 7 && hour < 9) || (hour == 9 && minute <= 30) ||
        (hour == 16 && minute >= 30) || (hour > 16 && hour < 20) || (hour == 20 && minute <= 30)) {
        return true; // It's peak hour
    }
    return false; // Not peak hour
}

void checkHeavyVehicleDuringPeak(float simulationTime, Vehicle& vehicle) {
    if (isPeakHour(simulationTime) && vehicle.type == VehicleType::Heavy) { 
        // If it's a heavy vehicle and it's peak hour, restrict the vehicle
        std::cout << "Heavy vehicle " << vehicle.numberPlate << " is not allowed during peak hours (" 
                  << getMockDateTimeString(simulationTime) << "). Vehicle will be stopped." << std::endl;
        // Implement logic to stop the vehicle or prevent its movement
        vehicle.speed = 0.0f; // Stop the vehicle or apply other restriction
    }
}

void update() {
    // Get the time passed since the last frame (deltaTime)
    float deltaTime = sfClock.restart().asSeconds()+ 1.0;  // in seconds

    // Update simulation time with the deltaTime
    updateSimulationTime(deltaTime);

    // Now simulationTime can be used to implement time-based logic
    std::cout << "Simulation Time: " << simulationTime << " seconds" << std::endl;

    // Your game logic and vehicle movement updates go here...

    // Example: Increase speed every 5 seconds
    if (int(simulationTime) % 50 == 0) {  // Every 5 seconds
        // Code to increase speed for all vehicles, etc.
        std::cout << "Speed increased for vehicles!" << std::endl;
    }
}


// Randomly break down vehicles
void randomlyBreakdownVehicles(Vehicle vehicles[], int numVehicles) {
    static bool hasBrokenDown = false;
    if (!hasBrokenDown && numVehicles > 0) {
        int randomIndex = rand() % numVehicles;
        vehicles[randomIndex].outOfOrder = true;
        std::cout << "Vehicle " << vehicles[randomIndex].numberPlate << " has broken down.\n";
        hasBrokenDown = true;
    }
}


// Other functions follow the same pattern as previously defined in your code.
void randomlyBreakdownVehicles_1(Vehicle1 vehicles[], int numVehicles) {
    static bool hasBrokenDown = false;
    if (!hasBrokenDown && numVehicles > 0) {
        int randomIndex = rand() % numVehicles;
        vehicles[randomIndex].outOfOrder = true;
        std::cout << "Vehicle " << vehicles[randomIndex].numberPlate << " has broken down.\n";
        hasBrokenDown = true;
    }
}

void randomlyBreakdownVehicles_2(Vehicle2 vehicles[], int numVehicles) {
    static bool hasBrokenDown = false;
    if (!hasBrokenDown && numVehicles > 0) {
        int randomIndex = rand() % numVehicles;
        vehicles[randomIndex].outOfOrder = true;
        std::cout << "Vehicle " << vehicles[randomIndex].numberPlate << " has broken down.\n";
        hasBrokenDown = true;
    }
}

void randomlyBreakdownVehicles_3(Vehicle3 vehicles[], int numVehicles) {
    static bool hasBrokenDown = false;
    if (!hasBrokenDown && numVehicles > 0) {
        int randomIndex = rand() % numVehicles;
        vehicles[randomIndex].outOfOrder = true;
        std::cout << "Vehicle " << vehicles[randomIndex].numberPlate << " has broken down.\n";
        hasBrokenDown = true;
    }
}



// Functions to maintain spacing between vehicles
void maintainSpacingNorthSouth(Vehicle1 vehicles[], int numVehicles, float spacing) {
    for (int i = 0; i < numVehicles; ++i) {
        for (int j = 0; j < numVehicles; ++j) {
            if (i != j && vehicles[i].lane == vehicles[j].lane) {
                if (fabs(vehicles[i].position.y - vehicles[j].position.y) < spacing) {
                    if (vehicles[i].position.y < vehicles[j].position.y) {
                        vehicles[j].position.y = vehicles[i].position.y + spacing;
                    } else {
                        vehicles[i].position.y = vehicles[j].position.y + spacing;
                    }
                }
            }
        }
    }
}

void maintainSpacingEastWest(Vehicle2 vehicles[], int numVehicles, float spacing) {
    for (int i = 0; i < numVehicles; ++i) {
        for (int j = 0; j < numVehicles; ++j) {
            if (i != j && vehicles[i].lane == vehicles[j].lane) {
                if (fabs(vehicles[i].position.x - vehicles[j].position.x) < spacing) {
                    if (vehicles[i].position.x > vehicles[j].position.x) {
                        vehicles[j].position.x = vehicles[i].position.x - spacing;
                    } else {
                        vehicles[i].position.x = vehicles[j].position.x - spacing;
                    }
                }
            }
        }
    }
}

void maintainSpacingWestEast(Vehicle3 vehicles[], int numVehicles, float spacing) {
    for (int i = 0; i < numVehicles; ++i) {
        for (int j = 0; j < numVehicles; ++j) {
            if (i != j && vehicles[i].lane == vehicles[j].lane) {
                if (fabs(vehicles[i].position.x - vehicles[j].position.x) < spacing) {
                    if (vehicles[i].position.x > vehicles[j].position.x) {
                        vehicles[j].position.x = vehicles[i].position.x - spacing;
                    } else {
                        vehicles[i].position.x = vehicles[j].position.x - spacing;
                    }
                }
            }
        }
    }
}

void maintainSpacing(Vehicle vehicles[], int numVehicles, float spacing) {
    for (int i = 0; i < numVehicles; ++i) {
        for (int j = 0; j < numVehicles; ++j) {
            if (i != j && vehicles[i].lane == vehicles[j].lane) {
                if (fabs(vehicles[i].position.y - vehicles[j].position.y) < spacing) {
                    if (vehicles[i].position.y > vehicles[j].position.y) {
                        vehicles[j].position.y = vehicles[i].position.y - spacing;
                    } else {
                        vehicles[i].position.y = vehicles[j].position.y - spacing;
                    }
                }
            }
        }
    }
}

// Functions to handle vehicles going out of bounds and shifting
void handleOutOfBoundsAndShift(Vehicle vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2) {
    for (int i = 0; i < numVehicles; ++i) {
        if (vehicles[i].position.y < -vehicles[i].sprite.getGlobalBounds().height) {
            Vehicle outOfBoundsVehicle = vehicles[i];
            for (int j = i; j < numVehicles - 1; ++j) {
                vehicles[j] = vehicles[j + 1];
            }
            outOfBoundsVehicle.position.y = 900.0f;
            outOfBoundsVehicle.lane = (rand() % 2 == 0) ? 1 : 2;
            outOfBoundsVehicle.position.x = (outOfBoundsVehicle.lane == 1) ? lane1 : lane2;
            outOfBoundsVehicle.sprite.setTexture(vehicleTextures[rand() % NUM_TEXTURES]);
            outOfBoundsVehicle.speed = 0.6f;
            outOfBoundsVehicle.timeOverLimit = 0.0f; // Reset time over limit
            outOfBoundsVehicle.challanIssued = false; // Reset challan flag
            vehicles[numVehicles - 1] = outOfBoundsVehicle;
            // No break; handle all out-of-bounds vehicles
        }
    }
}

void handleOutOfBoundsAndShift_northSouth(Vehicle1 vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2) {
    for (int i = 0; i < numVehicles; ++i) {
        if (vehicles[i].position.y > WINDOW_HEIGHT) {
            Vehicle1 outOfBoundsVehicle = vehicles[i];
            for (int j = i; j < numVehicles - 1; ++j) {
                vehicles[j] = vehicles[j + 1];
            }
            outOfBoundsVehicle.position.y = -20.0f;
            outOfBoundsVehicle.lane = (rand() % 2 == 0) ? 1 : 2;
            outOfBoundsVehicle.position.x = (outOfBoundsVehicle.lane == 1) ? lane1 : lane2;
            for (int k = 0; k < numVehicles - 1; ++k) {
                if (k != i && vehicles[k].lane == outOfBoundsVehicle.lane &&
                    fabs(vehicles[k].position.y - outOfBoundsVehicle.position.y) < VEHICLE_SPACING) {
                    outOfBoundsVehicle.position.y -= VEHICLE_SPACING;
                }
            }
            outOfBoundsVehicle.sprite.setTexture(vehicleTextures[rand() % NUM_TEXTURES]);
            outOfBoundsVehicle.speed = 0.5f;
            outOfBoundsVehicle.timeOverLimit = 0.0f; // Reset time over limit
            outOfBoundsVehicle.challanIssued = false; // Reset challan flag
            vehicles[numVehicles - 1] = outOfBoundsVehicle;
            // No break; handle all out-of-bounds vehicles
        }
    }
}

void handleOutOfBoundsAndShiftEastWest(Vehicle2 vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2) {
    for (int i = 0; i < numVehicles; ++i) {
        if (vehicles[i].position.x < -vehicles[i].sprite.getGlobalBounds().width) {
            Vehicle2 outOfBoundsVehicle = vehicles[i];
            for (int j = i; j < numVehicles - 1; ++j) {
                vehicles[j] = vehicles[j + 1];
            }
            outOfBoundsVehicle.position.x = WINDOW_WIDTH + VEHICLE_SPACING;
            outOfBoundsVehicle.lane = (rand() % 2 == 0) ? 1 : 2;
            outOfBoundsVehicle.position.y = (outOfBoundsVehicle.lane == 1) ? lane1 : lane2;
            outOfBoundsVehicle.sprite.setTexture(vehicleTextures[rand() % NUM_TEXTURES_1]);
            outOfBoundsVehicle.speed = 0.5f;
            outOfBoundsVehicle.timeOverLimit = 0.0f; // Reset time over limit
            outOfBoundsVehicle.challanIssued = false; // Reset challan flag
            vehicles[numVehicles - 1] = outOfBoundsVehicle;
            // No break; handle all out-of-bounds vehicles
        }
    }
}

void handleOutOfBoundsAndShiftWestEast(Vehicle3 vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2) {
    for (int i = 0; i < numVehicles; ++i) {
        if (vehicles[i].position.x > 1200) {
            Vehicle3 outOfBoundsVehicle = vehicles[i];
            for (int j = i; j < numVehicles - 1; ++j) {
                vehicles[j] = vehicles[j + 1];
            }
            // Correct lane assignment: 7 or 8
            outOfBoundsVehicle.lane = (rand() % 2 == 0) ? 7 : 8;
            outOfBoundsVehicle.position.x = 50.0f;
            outOfBoundsVehicle.position.y = (outOfBoundsVehicle.lane == 7) ? lane1 : lane2;
            outOfBoundsVehicle.sprite.setTexture(vehicleTextures[rand() % NUM_TEXTURES_1]);
            outOfBoundsVehicle.speed = 0.6f;
            outOfBoundsVehicle.timeOverLimit = 0.0f; // Reset time over limit
            outOfBoundsVehicle.challanIssued = false; // Reset challan flag
            vehicles[numVehicles - 1] = outOfBoundsVehicle;
            // No break; handle all out-of-bounds vehicles
        }
    }
}
