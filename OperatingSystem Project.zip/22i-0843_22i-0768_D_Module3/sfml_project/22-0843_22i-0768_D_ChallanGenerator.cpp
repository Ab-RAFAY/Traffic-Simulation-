#include "ChallanGenerator.h"
#include <iostream>
#include <fstream>
#include <sstream>

// Global variables for the queue and synchronization
std::mutex violationMutex;
std::condition_variable violationCV;
std::queue<Violation> violationQueue;

std::mutex userPortalMutex;
std::condition_variable userPortalCV;
std::queue<Challan> userPortalQueue;

const float SERVICE_CHARGE_PERCENTAGE = 0.17f;
const std::string CHALLAN_FILE = "challans.txt";

// Function to calculate fine
float calculateFine(const std::string& vehicleType) {
    if (vehicleType == "Heavy") {
        return 7000.0f;  
    } else if (vehicleType == "Regular") {
        return 5000.0f;  
    }
    return 0.0f;  
}


std::string generateChallanId() {
    static int challanCounter = 1;
    return "CH" + std::to_string(challanCounter++);
}


std::string getCurrentDateTime() {
    return "2024-12-08 14:51:26";  
}

std::string getDueDate(const std::string& issueDate) {
    return "2024-12-11 14:51:26";  // Placeholder for due date logic
}

void challanGeneratorFunction() {
    std::ofstream challanFile(CHALLAN_FILE, std::ios::app);
    if (!challanFile.is_open()) {
        std::cerr << "Failed to open challan file: " << CHALLAN_FILE << "\n";
        return;
    }

    while (true) {
        std::unique_lock<std::mutex> lock(violationMutex);
        violationCV.wait(lock, [] { return !violationQueue.empty(); });

        while (!violationQueue.empty()) {
            Violation v = violationQueue.front();
            violationQueue.pop();
            lock.unlock();

            // Calculate fine and service charge
            float fineAmount = calculateFine(v.vehicleType);
            float serviceCharge = fineAmount * SERVICE_CHARGE_PERCENTAGE;
            float totalAmountToPay = fineAmount + serviceCharge;

            // Generate Challan ID and dates
            std::string challanId = generateChallanId();
            std::string issueDate = getCurrentDateTime();
            std::string dueDate = getDueDate(issueDate);

            // Create the challan structure
            Challan challan;
            challan.challanId = challanId;
            challan.vehicleNumber = v.plate;
            challan.vehicleType = v.vehicleType;
            challan.amountToPay = totalAmountToPay;
            challan.paymentStatus = "Unpaid";
            challan.issueDate = issueDate;
            challan.dueDate = dueDate;

            // Write to challan file
            std::stringstream challanStream;
            challanStream << "Challan issued to vehicle: " << v.plate
                          << " for speed: " << v.speed
                          << " at " << v.dateTime
                          << " for vehicle type: " << v.vehicleType
                          << " Direction: " << v.dir
                          << "\nAmount to pay: " << totalAmountToPay
                          << " due by: " << dueDate
                          << "\nPayment Status: " << challan.paymentStatus
                          << "\n";

            {
                std::lock_guard<std::mutex> fileLock(userPortalMutex);
                challanFile << challanStream.str();
                challanFile.flush();  
            }

            {
                std::lock_guard<std::mutex> portalLock(userPortalMutex);
                userPortalQueue.push(challan);
            }
            userPortalCV.notify_one();  

            std::cout << challanStream.str();  
            lock.lock();
        }
    }

    challanFile.close();
}
