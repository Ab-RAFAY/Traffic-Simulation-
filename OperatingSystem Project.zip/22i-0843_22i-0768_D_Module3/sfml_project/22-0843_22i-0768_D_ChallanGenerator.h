#ifndef CHALLAN_GENERATOR_H
#define CHALLAN_GENERATOR_H

#include <string>
#include <queue>
#include <mutex>
#include <condition_variable>

// Structs and Types
struct Violation {
    std::string plate;
    float speed;
    std::string dateTime;
    std::string vehicleType;
    std::string dir;
};

struct Challan {
    std::string challanId;
    std::string vehicleNumber;
    std::string vehicleType;
    float amountToPay;
    std::string paymentStatus;
    std::string issueDate;
    std::string dueDate;
};

// Declare global variables
extern std::mutex violationMutex;
extern std::condition_variable violationCV;
extern std::queue<Violation> violationQueue;

extern std::mutex userPortalMutex;
extern std::condition_variable userPortalCV;
extern std::queue<Challan> userPortalQueue;

// Functions
void challanGeneratorFunction();
float calculateFine(const std::string& vehicleType);
std::string generateChallanId();
std::string getCurrentDateTime();
std::string getDueDate(const std::string& issueDate);

#endif // CHALLAN_GENERATOR_H
