#ifndef VEHICLE_UTILS_H
#define VEHICLE_UTILS_H

#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
#include <string>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <SFML/Graphics.hpp>


const int WINDOW_WIDTH = 1000;
const int WINDOW_HEIGHT = 800;
const float VEHICLE_SPACING = 100.0f;
const float LANE_X1 = 380.0f;
const float LANE_X2 = 435.0f;
const float LANE_X3 = 520.0f;
const float LANE_X4 = 570.0f;

const float LANE_X5 = 410.0f;
const float LANE_X6 = 450.0f;

const float LANE_X7 = 305.0f;
const float LANE_X8 = 347.0f;

const int MAX_VEHICLES = 5;
const int NUM_TEXTURES = 5;
const int NUM_TEXTURES_1 = 5;
extern float simulationTime;  // Declare simulationTime as external variable
extern sf::Clock sfClock;  



// Vehicle Types Enum
enum VehicleType { Regular, Heavy, Emergency };

// VehicleBase Structure
struct VehicleBase {
    sf::Sprite sprite;
    int lane;
    float speed;
    float maxSpeed;
    sf::Vector2f position;
    VehicleType type;
    std::string numberPlate;
    bool outOfOrder = false;
    int breakdownTimer = 0;
    bool challanIssued = false;
    float timeOverLimit = 0.0f;
    std::string typestr;
    std::string direction;
};

// Typedefs for vehicle types
typedef VehicleBase Vehicle;
typedef VehicleBase Vehicle1;
typedef VehicleBase Vehicle2;
typedef VehicleBase Vehicle3;

// Violation Structure



// Function declarations
std::string generateNumberPlate(int id);
void updateSimulationTime(float deltaTime);
void update();
void checkHeavyVehicleDuringPeak(float simulationTime, Vehicle& vehicle);
void randomlyBreakdownVehicles(Vehicle vehicles[], int numVehicles);
void randomlyBreakdownVehicles_1(Vehicle1 vehicles[], int numVehicles);
void randomlyBreakdownVehicles_2(Vehicle2 vehicles[], int numVehicles);
void randomlyBreakdownVehicles_3(Vehicle3 vehicles[], int numVehicles);
void maintainSpacing(Vehicle vehicles[], int numVehicles, float spacing);
void maintainSpacingNorthSouth(Vehicle1 vehicles[], int numVehicles, float spacing);
void maintainSpacingEastWest(Vehicle2 vehicles[], int numVehicles, float spacing);
void maintainSpacingWestEast(Vehicle3 vehicles[], int numVehicles, float spacing);
void handleOutOfBoundsAndShift(Vehicle vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2);
void handleOutOfBoundsAndShift_northSouth(Vehicle1 vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2);
void handleOutOfBoundsAndShiftEastWest(Vehicle2 vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2);
void handleOutOfBoundsAndShiftWestEast(Vehicle3 vehicles[], int numVehicles, sf::Texture vehicleTextures[], float lane1, float lane2);

#endif // VEHICLE_UTILS_H
