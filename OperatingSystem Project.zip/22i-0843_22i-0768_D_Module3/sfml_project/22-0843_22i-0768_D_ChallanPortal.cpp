#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <chrono>
#include <ctime>
#include <iomanip>

class ChallanManager {
public:
    
    void loadChallans(const std::string& filePath) {
        std::ifstream file(filePath);
        if (!file.is_open()) {
            std::cerr << "Failed to open challan file: " << filePath << "\n";
            return;
        }

        std::string line;
        Challan currentChallan;
        
        while (std::getline(file, line)) {
         
            line = trim(line);
            
          
            if (line.empty()) continue;

           
            if (line.find("-----------------------------------------") != std::string::npos) {
               
                if (!currentChallan.vehicleNumber.empty()) {
                    challans.push_back(currentChallan);
                    // Reset for the next challan
                    currentChallan = Challan();
                }
            }
            else {
                // Collect the information for the current challan
                parseLine(line, currentChallan);
            }
        }

        // Add the last challan if it has data
        if (!currentChallan.vehicleNumber.empty()) {
            challans.push_back(currentChallan);
        }

        file.close();
    }

    // Method to find a challan by vehicle plate number
    void getChallanByPlate(const std::string& plate) const {
        bool found = false;
        std::string formattedPlate = formatPlate(plate);

        for (const auto& challan : challans) {
            if (challan.vehicleNumber == formattedPlate) {
                printChallan(challan);
                found = true;
            }
        }

        if (!found) {
            std::cout << "No challan found for vehicle plate: " << plate << "\n";
        }
    }

    // Method to display all parsed challans
    void displayParsedChallans() const {
        for (const auto& challan : challans) {
            printChallan(challan);
        }
    }

    // Method to update payment status by challanID
    bool updatePaymentStatus(const std::string& challanID, const std::string& status) {
        for (auto& challan : challans) {
            if (challan.challanID == challanID) {
                challan.paymentStatus = status;
                return true;
            }
        }
        return false;
    }

    // Method to save challans back to the file
    void saveChallans(const std::string& filePath) const {
        std::ofstream file(filePath, std::ios::trunc);
        if (!file.is_open()) {
            std::cerr << "Failed to open challan file for writing: " << filePath << "\n";
            return;
        }

        for (const auto& challan : challans) {
            file << "Vehicle Plate: " << challan.vehicleNumber << "\n";
            file << "Speed: " << challan.speed << "\n";
            file << "Date: " << challan.date << "\n";
            file << "Vehicle Type: " << challan.vehicleType << "\n";
            file << "Direction: " << challan.direction << "\n";
            file << "Challan ID: " << challan.challanID << "\n";
            file << "Amount to Pay: " << challan.amountToPay << "\n";
            file << "Issue Date: " << challan.issueDate << "\n";
            file << "Due Date: " << challan.dueDate << "\n";
            file << "Payment Status: " << challan.paymentStatus << "\n";
            file << "-----------------------------------------\n";
        }

        file.close();
    }

private:
    struct Challan {
        std::string vehicleNumber;
        std::string speed;
        std::string date;
        std::string vehicleType;
        std::string direction;
        std::string challanID;
        std::string amountToPay;
        std::string issueDate;
        std::string dueDate;
        std::string paymentStatus;
    };

    std::vector<Challan> challans;

    // Helper function to parse each line and add information to the challan object
    void parseLine(const std::string& line, Challan& challan) {
        std::size_t pos = line.find(":");
        if (pos == std::string::npos) return;

        std::string key = trim(line.substr(0, pos));
        std::string value = trim(line.substr(pos + 1));

        if (key == "Vehicle Plate") {
            challan.vehicleNumber = value;
        }
        else if (key == "Speed") {
            challan.speed = value;
        }
        else if (key == "Date") {
            challan.date = value;
        }
        else if (key == "Vehicle Type") {
            challan.vehicleType = value;
        }
        else if (key == "Direction") {
            challan.direction = value;
        }
        else if (key == "Challan ID") {
            challan.challanID = value;
        }
        else if (key == "Amount to Pay") {
            challan.amountToPay = value;
        }
        else if (key == "Issue Date") {
            challan.issueDate = value;
        }
        else if (key == "Due Date") {
            challan.dueDate = value;
        }
        else if (key == "Payment Status") {
            challan.paymentStatus = value;
        }
    }


    std::string trim(const std::string& str) const {
        auto start = str.begin();
        while (start != str.end() && std::isspace(*start)) {
            start++;
        }

        if (start == str.end()) {
            return "";
        }

        auto end = str.end() - 1;
        while (end > start && std::isspace(*end)) {
            end--;
        }

        return std::string(start, end + 1);
    }

    // Helper function to format plate numbers (if needed)
    std::string formatPlate(const std::string& plate) const {
        if (plate.size() == 6) { // This is the case for just a numeric part like "000190"
            return "CAR-" + plate;
        }
        return plate;
    }

    // Helper function to print a single challan
    void printChallan(const Challan& challan) const {
        std::cout << "\n--- Challan Details ---\n";
        std::cout << "Vehicle Number: " << challan.vehicleNumber << "\n";
        std::cout << "Speed: " << challan.speed << "\n";
        std::cout << "Date: " << challan.date << "\n";
        std::cout << "Vehicle Type: " << challan.vehicleType << "\n";
        std::cout << "Direction: " << challan.direction << "\n";
        std::cout << "Challan ID: " << challan.challanID << "\n";
        std::cout << "Amount to Pay: " << challan.amountToPay << "\n";
        std::cout << "Issue Date: " << challan.issueDate << "\n";
        std::cout << "Due Date: " << challan.dueDate << "\n";
        std::cout << "Payment Status: " << challan.paymentStatus << "\n";
        std::cout << "-------------------------\n";
    }
};

class StripePayment {
public:
    // Method to simulate Stripe payment process
    void processPayment(int pipeFd[], const std::string& challanID, const std::string& vehicleNumber, 
                        const std::string& vehicleType, const std::string& amountToPay,
                        ChallanManager& manager, const std::string& filePath) {
        // The child process will write the payment status to the pipe
        pid_t pid = fork();

        if (pid == 0) {
            // Child process simulates the payment
            close(pipeFd[0]);  // Close unused read end of the pipe

            // Ask user for payment amount
            double paidAmount;
            std::cout << "Enter the amount to pay for the vehicle " << vehicleNumber << " (" 
                      << vehicleType << "): ";
            std::cin >> paidAmount;

            double amountToBePaid = std::stod(amountToPay);
            std::string paymentStatus;

            if (paidAmount >= amountToBePaid) {
                paymentStatus = "Successful";
                std::cout << "Payment successful! Amount paid: " << paidAmount << "\n";
            } else {
                paymentStatus = "Failed";
                std::cout << "Insufficient amount. Payment failed.\n";
            }

            // Send payment status and challan details to the parent process
            std::string message = challanID + "|" + paymentStatus;
            write(pipeFd[1], message.c_str(), message.length() + 1);  // Send payment info to parent

            close(pipeFd[1]);  // Close write end of the pipe
            exit(0);  // End child process
        } else if (pid > 0) {
            // Parent process (ChallanManager) reads the payment status from the pipe
            close(pipeFd[1]);  

            char buffer[256];
            ssize_t n = read(pipeFd[0], buffer, sizeof(buffer));  
            if (n > 0) {
                std::cout << "Payment Status Received: " << buffer << "\n";

                // Extract challanID and status
                std::string receivedChallanID;
                std::string paymentStatus;
                std::stringstream ss(buffer);
                std::getline(ss, receivedChallanID, '|');
                std::getline(ss, paymentStatus, '|');

                // Update the challan in manager
                if (manager.updatePaymentStatus(receivedChallanID, paymentStatus)) {
                    std::cout << "Challan status updated successfully.\n";
                    manager.saveChallans(filePath);
                }
                else {
                    std::cerr << "Failed to update challan status. Challan ID not found.\n";
                }
            }
            else {
                std::cerr << "Failed to read payment status from pipe.\n";
            }

            close(pipeFd[0]);  
            wait(NULL);  
        } else {
            std::cerr << "Fork failed\n";
        }
    }
};

int main() {
    ChallanManager manager;
    StripePayment stripePayment;

    std::string filePath = "challans.txt"; 
    manager.loadChallans(filePath);

    while (true) {
        std::cout << "\n1. Display All Challans\n2. Search Challan by Plate\n3. Process Payment\n4. Exit\n";
        std::cout << "Choose an option: ";
        
        int option;
        std::cin >> option;
        
        if (option == 1) {
            manager.displayParsedChallans();
        } 
        else if (option == 2) {
            std::string plate;
            std::cout << "\nEnter the vehicle plate number to search: ";
            std::cin >> plate;
            manager.getChallanByPlate(plate);
        } 
        else if (option == 3) {
            std::string challanID, vehicleNumber, vehicleType, amountToPay;
            std::cout << "\nEnter Challan ID: ";
            std::cin >> challanID;
            std::cout << "Enter Vehicle Number: ";
            std::cin >> vehicleNumber;
            std::cout << "Enter Vehicle Type: ";
            std::cin >> vehicleType;
            std::cout << "Enter Amount to Pay: ";
            std::cin >> amountToPay;
            
            // Simulate payment process
            int pipeFd[2];
            if (pipe(pipeFd) == -1) {
                std::cerr << "Failed to create pipe.\n";
                continue;
            }
            stripePayment.processPayment(pipeFd, challanID, vehicleNumber, vehicleType, amountToPay, manager, filePath);
        } 
        else if (option == 4) {

             try {
                // Generate timestamp for unique filename
                auto now = std::chrono::system_clock::now();
                std::time_t time_now = std::chrono::system_clock::to_time_t(now);
                
                // Create filename with timestamp
                std::stringstream filename;
                filename << "updatedChallan_" 
                         << std::put_time(std::localtime(&time_now), "%Y%m%d_%H%M%S") 
                         << ".txt";
                
                // Save challans to the new backup file
                manager.saveChallans(filename.str());
                
                std::cout << "Challans backed up to: " << filename.str() << "\n";
                std::cout << "Exiting...\n";
                break;
            }
            catch (const std::exception& e) {
                std::cerr << "Error creating backup file: " << e.what() << "\n";
                std::cout << "Exiting...\n";
                break;
            }
        } 
            
        else {
            std::cout << "Invalid option. Please try again.\n";
        }
    }

    return 0;
}
