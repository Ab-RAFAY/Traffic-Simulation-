// Compile with: g++ -g main.cpp -o sfml_app -lsfml-graphics -lsfml-window -lsfml-system -pthread
// Run with: ./sfml_app
#include "vehicle_utils.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <cstdlib> // For rand()
#include <ctime>   // For seeding rand()
#include <cmath>   // For abs()
#include <vector>
#include <random>
#include <string>
#include <sstream>
#include <iomanip>
#include <thread>
#include <mutex>
#include <chrono>
#include <queue>
#include <condition_variable>
#include <fstream> // For file operations
#include <unordered_map>




using namespace std;

// Constants

// Vehicle Types

// Structure for Violations
struct Violation {
    std::string plate;
    float speed;
    std::string dateTime; // Added dateTime field
    std::string vehicleType;  // New field for vehicle type
    std::string dir;
};

// Struct for Challan details
struct Challan {
    std::string challanId;
    std::string vehicleNumber;
    std::string vehicleType;
    float amountToPay;
    std::string paymentStatus;  // "Paid", "Unpaid", "Overdue"
    std::string issueDate;
    std::string dueDate;
};


// Global Variables
std::queue<Violation> violationQueue;
std::mutex violationMutex;
std::condition_variable violationCV;

const float SERVICE_CHARGE_PERCENTAGE = 0.17f;

// Helper function to generate a Challan ID (just for simplicity here)
std::string generateChallanId() {
    static int challanIdCounter = 1;
    std::stringstream challanId;
    challanId << "CH-" << challanIdCounter++;
    return challanId.str();
}

// Helper function to calculate the fine
float calculateFine(const std::string& vehicleType) {
    if (vehicleType == "Regular") {
        return 5000.0f;  // Fine for regular vehicles
    } else if (vehicleType == "Heavy") {
        return 7000.0f;  // Fine for heavy vehicles
    }
    return 0.0f;  // Emergency vehicles are exempt
}

// Helper function to get the current date-time string
std::string getCurrentDateTime() {
    auto now = std::chrono::system_clock::now();
    std::time_t now_c = std::chrono::system_clock::to_time_t(now);
    std::tm* now_tm = std::localtime(&now_c);
    std::stringstream ss;
    ss << std::put_time(now_tm, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

// Helper function to get the due date (3 days after the challan issue date)
std::string getDueDate(const std::string& issueDate) {
    // In a real application, you would need to calculate the date 3 days later.
    // Here, for simplicity, we'll assume the due date is just a hardcoded value.
    return "2024-12-11";  // 3 days from a given date (replace this with actual date calculation)
}

// Function to simulate sending challan details to UserPortal (simple print here)
void sendChallanToUserPortal(const Challan& challan) {
    // Simulate sending challan to the user portal
    std::cout << "Sending Challan to UserPortal: \n";
    std::cout << "Challan ID: " << challan.challanId << "\n";
    std::cout << "Vehicle Number: " << challan.vehicleNumber << "\n";
    std::cout << "Vehicle Type: " << challan.vehicleType << "\n";
    std::cout << "Amount to Pay: " << challan.amountToPay << "\n";
    std::cout << "Due Date: " << challan.dueDate << "\n";
}



// Global variables
std::map<std::string, int> vehicleCountPerDirection;  // To store vehicle counts per direction
std::mutex vehicleCountMutex;  // Mutex for thread-safety
const std::string VEHICLE_COUNT_FILE = "vehicle_count.txt";  // Fil

int currentState = 0; // Traffic light state
std::mutex stateMutex;

// Speed limit constant
const float SPEED_LIMIT = 1.2f; // Example speed limit

// Mutex for file writing
std::mutex fileMutex;

// Challan file path
const std::string CHALLAN_FILE = "challans.txt";




// Traffic light controller thread function
void trafficLightController() {
    while (true) {
        // Determine sleep duration based on current state
        int sleepDuration = 0;
        {
            std::lock_guard<std::mutex> lock(stateMutex);
            switch (currentState) {
                case 0: // N-S Green
                case 2: // W-E Green
                case 4: // S-N Green
                case 6: // E-W Green
                    sleepDuration = 10000; // 10 seconds
                    break;
                case 1: // N-S Yellow
                case 3: // W-E Yellow
                case 5: // S-N Yellow
                case 7: // E-W Yellow
                    sleepDuration = 3000; // 3 seconds
                    break;
                default:
                    sleepDuration = 10000; // Default to 10 seconds
                    break;
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(sleepDuration));

        // Update traffic light state
        {
            std::lock_guard<std::mutex> lock(stateMutex);
            currentState = (currentState + 1) % 8; // Cycle through 8 states
            std::cout << "Traffic light state changed to: " << currentState << "\n";
        }
    }
}


void updateVehicleCount(const std::string& direction) {
    std::lock_guard<std::mutex> lock(vehicleCountMutex);  // Ensure thread-safety

    // Increment the count for the direction
    vehicleCountPerDirection[direction]++;
}


void onVehicleEnterLane(const std::string& direction) {
    std::lock_guard<std::mutex> lock(vehicleCountMutex);
    vehicleCountPerDirection[direction]++;
}


std::string convertTypeToString(VehicleType type) {
    switch (type) {
        case Regular:
            return "Regular";
        case Heavy:
            return "Heavy";
        case Emergency:
            return "Emergency";
        default:
            return "Unknown";
    }
}

void vehicleCountWriterFunction() {
    // Open the vehicle count file in append mode
    std::ofstream vehicleCountFile(VEHICLE_COUNT_FILE, std::ios::app);
    if (!vehicleCountFile.is_open()) {
        std::cerr << "Failed to open vehicle count file: " << VEHICLE_COUNT_FILE << "\n";
        return;
    }

    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(10));  // Sleep for 10 seconds (or adjust as needed)

        // Lock the mutex before accessing the vehicle count map
        std::lock_guard<std::mutex> lock(vehicleCountMutex);

        // Write the vehicle counts to the file
        vehicleCountFile << "Vehicle counts at " << getCurrentDateTime() << ":\n";
        for (const auto& entry : vehicleCountPerDirection) {
            vehicleCountFile << "Direction: " << entry.first 
                             << " Total vehicles: " << entry.second << "\n";
        }

        // Ensure data is written immediately
        vehicleCountFile.flush();
        std::cout << "Vehicle counts written to file.\n";
    }

    vehicleCountFile.close();
}

void challanGeneratorFunction() {
    // Open the challan file in append mode
    std::ofstream challanFile(CHALLAN_FILE, std::ios::app);
    if (!challanFile.is_open()) {
        std::cerr << "Failed to open challan file: " << CHALLAN_FILE << "\n";
        return;
    }

    while (true) {
        std::unique_lock<std::mutex> lock(violationMutex);
        violationCV.wait(lock, [] { return !violationQueue.empty(); });

        // Process all queued violations
        while (!violationQueue.empty()) {
            Violation v = violationQueue.front();
            violationQueue.pop();
            lock.unlock();  // Unlock while processing

            // Calculate fine based on vehicle type
            float fineAmount = calculateFine(v.vehicleType);

            // Apply service charge (17%)
            float serviceCharge = fineAmount * SERVICE_CHARGE_PERCENTAGE;
            float totalAmountToPay = fineAmount + serviceCharge;

            // Generate Challan ID
            std::string challanId = generateChallanId();

            // Get current date-time and calculate due date (3 days from issue date)
            std::string issueDate = getCurrentDateTime();
            std::string dueDate = getDueDate(issueDate);

            // Create the challan structure
            Challan challan;
            challan.challanId = challanId;
            challan.vehicleNumber = v.plate;
            challan.vehicleType = v.vehicleType;
            challan.amountToPay = totalAmountToPay;
            challan.paymentStatus = "Unpaid";  // Default to unpaid
            challan.issueDate = issueDate;
            challan.dueDate = dueDate;

            // Write the challan details to the file in a simplified structure
            {
                std::lock_guard<std::mutex> fileLock(fileMutex);

                challanFile << "Vehicle Plate: " << v.plate << "\n"
                            << "Speed: " << v.speed << "\n"
                            << "Date: " << v.dateTime << "\n"
                            << "Vehicle Type: " << v.vehicleType << "\n"
                            << "Direction: " << v.dir << "\n"
                            << "Challan ID: " << challan.challanId << "\n"
                            << "Amount to Pay: " << totalAmountToPay << "\n"
                            << "Issue Date: " << issueDate << "\n"
                            << "Due Date: " << dueDate << "\n"
                            << "Payment Status: " << challan.paymentStatus << "\n"
                            << "-----------------------------------------\n";

                challanFile.flush(); // Ensure data is written immediately
            }

            // Send challan details to the UserPortal (this can be a separate thread or service)
            sendChallanToUserPortal(challan);

            std::cout << "Challan details sent to user portal.\n"; // Optionally, also print to console

            lock.lock();  // Re-lock to check for next violation
        }
    }

    challanFile.close();
}


// Function to get current mock date-time as string
std::string getMockDateTimeString(std::chrono::system_clock::time_point mockTime) {
    std::time_t timeT = std::chrono::system_clock::to_time_t(mockTime);
    std::tm* tmPtr = std::localtime(&timeT);
    char buffer[100];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tmPtr);
    return std::string(buffer);
}

int main() {
    srand(static_cast<unsigned>(time(0)));
    sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Traffic Simulation with Threads & Speed Limit");

    // Load background
    sf::Texture backgroundTexture;
    if (!backgroundTexture.loadFromFile("/home/ali512/Downloads/sprites/6.jpg")) {
        std::cerr << "Failed to load background texture.\n";
        return -1;
    }
    sf::Sprite backgroundSprite(backgroundTexture);
    sf::Vector2u bgSize = backgroundTexture.getSize();
    backgroundSprite.setScale(
        static_cast<float>(WINDOW_WIDTH) / bgSize.x,
        static_cast<float>(WINDOW_HEIGHT) / bgSize.y
    );

   sf::Texture redLight, greenLight, yellowLight; // Added yellowLight
if (!redLight.loadFromFile("/home/ali512/Downloads/sprites/red.png") ||
    !greenLight.loadFromFile("/home/ali512/Downloads/sprites/green.png") ||
    !yellowLight.loadFromFile("/home/ali512/Downloads/sprites/yellow.png")) { // Load yellow.png
    std::cerr << "Failed to load traffic light textures.\n";
    return -1;
}

// N-S traffic lights
sf::Sprite trafficLight_red_ns(redLight), trafficLight_green_ns(greenLight), trafficLight_yellow_ns(yellowLight);
trafficLight_red_ns.setPosition(331, 78);
trafficLight_red_ns.setScale(0.04f, 0.04f);
trafficLight_green_ns.setPosition(332, 108);
trafficLight_green_ns.setScale(0.038f, 0.038f);
trafficLight_yellow_ns.setPosition(331, 93); // Positioned between red and green
trafficLight_yellow_ns.setScale(0.04f, 0.04f);

// S-N traffic lights
sf::Sprite trafficLight_red_sn(redLight), trafficLight_green_sn(greenLight), trafficLight_yellow_sn(yellowLight);
trafficLight_red_sn.setPosition(655, 590);
trafficLight_red_sn.setScale(0.04f, 0.04f);
trafficLight_green_sn.setPosition(655, 619);
trafficLight_green_sn.setScale(0.038f, 0.038f);
trafficLight_yellow_sn.setPosition(655, 604); // Positioned between red and green
trafficLight_yellow_sn.setScale(0.04f, 0.04f);

// W-E traffic lights
sf::Sprite trafficLight_red_we(redLight), trafficLight_green_we(greenLight), trafficLight_yellow_we(yellowLight);
trafficLight_red_we.setPosition(173, 515);
trafficLight_red_we.setScale(0.04f, 0.04f);
trafficLight_green_we.setPosition(174, 545);
trafficLight_green_we.setScale(0.038f, 0.038f);
trafficLight_yellow_we.setPosition(173, 530); // Positioned between red and green
trafficLight_yellow_we.setScale(0.04f, 0.04f);

// E-W traffic lights
sf::Sprite trafficLight_red_ew(redLight), trafficLight_green_ew(greenLight), trafficLight_yellow_ew(yellowLight);
trafficLight_red_ew.setPosition(793, 168);
trafficLight_red_ew.setScale(0.04f, 0.04f);
trafficLight_green_ew.setPosition(794, 198);
trafficLight_green_ew.setScale(0.038f, 0.038f);
trafficLight_yellow_ew.setPosition(793, 183); // Positioned between red and green
trafficLight_yellow_ew.setScale(0.04f, 0.04f);


    // Load vehicle textures
    sf::Texture vehicleTextures[NUM_TEXTURES];
    string texturePaths[NUM_TEXTURES] = {
        "/home/ali512/Downloads/sprites/6a.png",
        "/home/ali512/Downloads/sprites/6b.png",
        "/home/ali512/Downloads/sprites/truck1.png",
        "/home/ali512/Downloads/sprites/1a.png",
        "/home/ali512/Downloads/sprites/ambu1.png"
    };

    for (int i = 0; i < NUM_TEXTURES; ++i) {
        if (!vehicleTextures[i].loadFromFile(texturePaths[i])) {
            std::cerr << "Failed to load vehicle texture: " << texturePaths[i] << "\n";
            return -1;
        }
    }

    sf::Texture vehicleTextures_1[NUM_TEXTURES_1];
    string texturePaths_1[NUM_TEXTURES_1] = {
        "/home/ali512/Downloads/sprites/1aa.png",
        "/home/ali512/Downloads/sprites/6aa.png",
        "/home/ali512/Downloads/sprites/6bb.png",
        "/home/ali512/Downloads/sprites/truck1a.png",
        "/home/ali512/Downloads/sprites/ambu1a.png"
    };

    for (int i = 0; i < NUM_TEXTURES_1; ++i) {
        if (!vehicleTextures_1[i].loadFromFile(texturePaths_1[i])) {
            std::cerr << "Failed to load vehicle texture: " << texturePaths_1[i] << "\n";
            return -1;
        }
    }

    // Initialize Vehicles East to West
    Vehicle2 eastWestVehicles[MAX_VEHICLES];
    for (int i = 0; i < MAX_VEHICLES; ++i) {
        VehicleType type;
        if (rand() % 5 == 0) {
            type = Emergency;
        }
        else if (rand() % 15 == 0) {
            type = Heavy;
        }
        else {
            type = Regular;
        }

        eastWestVehicles[i].type = type;
        eastWestVehicles[i].typestr = convertTypeToString(type);  
        eastWestVehicles[i].numberPlate = generateNumberPlate(i);  
        eastWestVehicles[i].direction= "E-W";   
           onVehicleEnterLane("E-W");     
        eastWestVehicles[i].lane = (type == Heavy) ? 6 : ((i % 2 == 0) ? 5 : 6);
        switch (type) {
            case Regular:
                eastWestVehicles[i].maxSpeed = 1.3f;  
                break;
            case Heavy:
                eastWestVehicles[i].maxSpeed = 1.1f;  
                break;
            case Emergency:
                eastWestVehicles[i].maxSpeed = 1.2f;  
                break;
        }
            eastWestVehicles[i].speed = 0.6f;
        if (type == Emergency) {
            eastWestVehicles[i].sprite.setTexture(vehicleTextures_1[4]);  
        }
        else if (type == Heavy) {
            eastWestVehicles[i].sprite.setTexture(vehicleTextures_1[3]);  
        }
        else {
            eastWestVehicles[i].sprite.setTexture(vehicleTextures_1[rand() % 2]); 
        }

        eastWestVehicles[i].sprite.setScale(0.1f, 0.1f);
        eastWestVehicles[i].position = {
            850.0f + i * VEHICLE_SPACING,
            (eastWestVehicles[i].lane == 5 ? LANE_X5 : LANE_X6)
        };
        eastWestVehicles[i].sprite.setPosition(eastWestVehicles[i].position);
    }

    // Initialize Vehicles West to East
    Vehicle3 WestEastVehicles[MAX_VEHICLES];
    for (int i = 0; i < MAX_VEHICLES; ++i) {
        VehicleType type;
        if (rand() % 5 == 0) {
            type = Emergency;
        }
        else if (rand() % 15 == 0) {
            type = Heavy;
        }
        else {
            type = Regular;
        }

        WestEastVehicles[i].type = type;
        WestEastVehicles[i].typestr = convertTypeToString(type);  
        WestEastVehicles[i].lane = (type == Heavy) ? 8 : ((i % 2 == 0) ? 7 : 8);
        WestEastVehicles[i].numberPlate = generateNumberPlate(i);     
        WestEastVehicles[i].direction= "W-E";
         onVehicleEnterLane("W-E");     


        switch (type) {
            case Regular:
                WestEastVehicles[i].maxSpeed = 1.3f;  
                break;
            case Heavy:
                WestEastVehicles[i].maxSpeed = 1.1f;  
                break;
            case Emergency:
                WestEastVehicles[i].maxSpeed = 1.2f;  
                break;
        }
            WestEastVehicles[i].speed = 0.5f;

        if (type == Emergency) {
            WestEastVehicles[i].sprite.setTexture(vehicleTextures_1[4]);  
        }
        else if (type == Heavy) {
            WestEastVehicles[i].sprite.setTexture(vehicleTextures_1[3]);  
        }
        else {
            WestEastVehicles[i].sprite.setTexture(vehicleTextures_1[rand() % 2]); 
        }

        WestEastVehicles[i].sprite.setScale(0.1f, 0.1f);
        WestEastVehicles[i].position = {
            250.0f - i * VEHICLE_SPACING,
            (WestEastVehicles[i].lane == 7 ? LANE_X7 : LANE_X8)
        };
        WestEastVehicles[i].sprite.setPosition(WestEastVehicles[i].position);
    }

    // Initialize Vehicles North to South
    Vehicle1 northSouthVehicles[MAX_VEHICLES];
    for (int i = 0; i < MAX_VEHICLES; ++i) {
        VehicleType type;
        if (rand() % 5 == 0) { 
            type = Emergency;
        }
        else if (rand() % 15 == 0) {
            type = Heavy;
        }
        else {
            type = Regular;
        }

        northSouthVehicles[i].type = type;
        northSouthVehicles[i].typestr = convertTypeToString(type);  
        northSouthVehicles[i].lane = (type == Heavy) ? 4 : ((i % 2 == 0) ? 1 : 2);
        northSouthVehicles[i].numberPlate = generateNumberPlate(i);                
        northSouthVehicles[i].direction= "N-S";
        onVehicleEnterLane("N-S");     

        switch (type) {
            case Regular:
                northSouthVehicles[i].maxSpeed = 1.3f;  
                break;
            case Heavy:
                northSouthVehicles[i].maxSpeed = 1.1f;  
                break;
            case Emergency:
                northSouthVehicles[i].maxSpeed = 1.2f;  
                break;
        }
            northSouthVehicles[i].speed = 0.6f;

        if (type == Emergency) {
            northSouthVehicles[i].sprite.setTexture(vehicleTextures[4]); 
        }
        else if (type == Heavy) {
            northSouthVehicles[i].sprite.setTexture(vehicleTextures[2]); 
        }
        else {
            northSouthVehicles[i].sprite.setTexture(vehicleTextures[rand() % 2]); 
        }

        northSouthVehicles[i].sprite.setScale(0.1f, 0.1f);
        northSouthVehicles[i].position = {
            (northSouthVehicles[i].lane == 1 ? LANE_X3 : LANE_X4),
            200 - i * VEHICLE_SPACING
        };
        northSouthVehicles[i].sprite.setPosition(northSouthVehicles[i].position);
    }

    // Initialize Vehicles South to North
    Vehicle vehicles[MAX_VEHICLES];
    for (int i = 0; i < MAX_VEHICLES; ++i) {
        VehicleType type;
        if (rand() % 5 == 0) { 
            type = Emergency;
        }
        else if (rand() % 15 == 0) { 
            type = Heavy;
        }
        else {
            type = Regular;
        }

        vehicles[i].type = type;
        vehicles[i].typestr = convertTypeToString(type);  
        vehicles[i].lane = (type == Heavy) ? 2 : ((i % 2 == 0) ? 1 : 2);  
        vehicles[i].numberPlate = generateNumberPlate(i);      
        vehicles[i].direction= "S-N";  
        onVehicleEnterLane("S-N");     

        switch (type) {
            case Regular:
                vehicles[i].maxSpeed = 1.3f;  
                break;
            case Heavy:
                vehicles[i].maxSpeed = 1.1f;  
                break;
            case Emergency:
                vehicles[i].maxSpeed = 1.2f;  
                break;
        }

        vehicles[i].speed = 0.5f;

        if (type == Emergency) {
            vehicles[i].sprite.setTexture(vehicleTextures[4]);  
        }
        else if (type == Heavy) {
            vehicles[i].sprite.setTexture(vehicleTextures[0]); 
        }
        else {
            vehicles[i].sprite.setTexture(vehicleTextures[rand() % 2]); 
        }

        vehicles[i].sprite.setScale(0.1f, 0.1f);
        vehicles[i].position = {
            (vehicles[i].lane == 1 ? LANE_X1 : LANE_X2),
            915.0f - i * VEHICLE_SPACING
        };
        vehicles[i].sprite.setPosition(vehicles[i].position);
    }

    // Load font for clock display
    sf::Font font;
    if (!font.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")) { // Adjust the path as needed
        std::cerr << "Failed to load font.\n";
        return -1;
    }

    // Initialize clock text
    sf::Text clockText;
    clockText.setFont(font);
    clockText.setCharacterSize(24);
    clockText.setFillColor(sf::Color::Black);
    clockText.setPosition(10.0f, 10.0f); // Top-left corner

    // Initialize mock date-time
    // Start at 2024-01-01 06:00:00
    std::tm initialTime = {};
    initialTime.tm_sec = 0;
    initialTime.tm_min = 0;
    initialTime.tm_hour = 6;
    initialTime.tm_mday = 1;
    initialTime.tm_mon = 0; // January
    initialTime.tm_year = 124; // Years since 1900 (124 for 2024)
    std::chrono::system_clock::time_point mockTime = std::chrono::system_clock::from_time_t(std::mktime(&initialTime));

    // Start Traffic Light Controller Thread
    std::thread tLights(trafficLightController);
    tLights.detach();

    // Start Challan Generator Thread
    std::thread tChallan(challanGeneratorFunction);
    tChallan.detach();


    std::thread vehicleCountWriter(vehicleCountWriterFunction);

    // Junction coordinates
    const float JUNCTION_Y = 510.0f;
    const float JUNCTION_Y_1 = 280.0f;
    const float JUNCTION_X = 620.0f;
    const float JUNCTION_X_1 = 307.0f;

    // Main Simulation Loop
    int simulationTime = 0; // Time in frames
    while (window.isOpen()) 
    {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Read current traffic light state
        int localState;
        {
            std::lock_guard<std::mutex> lock(stateMutex);
            localState = currentState;
        }

        simulationTime++;

        // Advance mock time
        // For example, each frame advances mock time by 1 second
        mockTime += std::chrono::seconds(1); // Adjust as needed for testing

        // Update clock display
        std::string mockDateTimeStr = getMockDateTimeString(mockTime);
        clockText.setString("Mock Time: " + mockDateTimeStr);

       // Determine traffic light colors based on state
bool isGreenNS = (localState == 0);
bool isYellowNS = (localState == 1);

bool isGreenWE = (localState == 2);
bool isYellowWE = (localState == 3);

bool isGreenSN = (localState == 4);
bool isYellowSN = (localState == 5);

bool isGreenEW = (localState == 6);
bool isYellowEW = (localState == 7);

// Red is true when not green or yellow
bool isRedNS = !(isGreenNS || isYellowNS);
bool isRedWE = !(isGreenWE || isYellowWE);
bool isRedSN = !(isGreenSN || isYellowSN);
bool isRedEW = !(isGreenEW || isYellowEW);

        // Update Vehicles South to North
        randomlyBreakdownVehicles(vehicles, MAX_VEHICLES); 
        for (int i = 0; i < MAX_VEHICLES; ++i) {
            checkHeavyVehicleDuringPeak(simulationTime, vehicles[i]);
            bool canMove = true;

            // Handle out-of-order vehicles
            if (vehicles[i].outOfOrder) {
                vehicles[i].sprite.setColor(sf::Color::Red);
                canMove = false;
                vehicles[i].breakdownTimer++;
                if (vehicles[i].breakdownTimer > 700) {
                    vehicles[i].outOfOrder = false;
                    vehicles[i].sprite.setColor(sf::Color::White);
                    vehicles[i].breakdownTimer = 0;
                }
            }

            // Junction logic
            if (!isGreenSN && vehicles[i].position.y > JUNCTION_Y && !vehicles[i].outOfOrder) {
                canMove = false;
            }

            // Reduce speed after leaving the junction
            if (vehicles[i].position.y > JUNCTION_Y + 30) {
                vehicles[i].speed = std::max(vehicles[i].speed - 0.8f, 0.4f); // Gradually reduce speed
            }

            //if (vehicles[i].type == Emergency) {
            //    for (int j = 0; j < MAX_VEHICLES; ++j) {
            //        if (i != j && vehicles[j].lane == vehicles[i].lane && vehicles[j].position.y > vehicles[i].position.y) {
            //            // Speed up the vehicle in front
            //            vehicles[j].speed = std::min(vehicles[j].speed + 0.4f, vehicles[j].maxSpeed * 1.5f); // Temporary boost
            //            vehicles[i].speed = std::min(vehicles[i].speed + 0.4f, vehicles[i].maxSpeed * 1.5f); // Emergency speed boost
            //        }
            //    }
            //}

            // Maintain safe distance from other vehicles
            for (int j = 0; j < MAX_VEHICLES; ++j) {
                if (i != j && vehicles[i].lane == vehicles[j].lane) {
                    if (vehicles[i].position.y > vehicles[j].position.y &&
                        vehicles[i].position.y - vehicles[j].position.y < VEHICLE_SPACING) {
                        canMove = false;
                        break;
                    }
                }
            }

            if (int(simulationTime) % 50 == 0) {  // Every 5 seconds
                if (rand() % 2 == 0) {  // Randomly pick some vehicles (50% chance)
                    if (vehicles[i].speed + 0.6f <= vehicles[i].maxSpeed) {
                        vehicles[i].speed += 0.6f;  // Increase speed by 0.5 km/h or 5 km/h
                    }
                }
                
            }

            // Allow vehicles to move if conditions are met
            if (canMove) {
                vehicles[i].position.y -= vehicles[i].speed;
            }
            vehicles[i].sprite.setPosition(vehicles[i].position);

            // Speed limit violation check
            if (simulationTime > 300) { // For testing, you can reduce this number
                if (vehicles[i].speed > SPEED_LIMIT) {
                    vehicles[i].timeOverLimit += 1.0f; // Assuming each frame represents 1 second
                    if (vehicles[i].timeOverLimit >= 2.0f && !vehicles[i].challanIssued) { // 5-second threshold
                        // Create Violation with current mock date-time
                        Violation v;
                        v.plate = vehicles[i].numberPlate;
                        v.speed = vehicles[i].speed;
                        v.dateTime = getMockDateTimeString(mockTime);
                        v.vehicleType= vehicles[i].typestr;
                        v.dir= vehicles[i].direction;

                        {
                            std::lock_guard<std::mutex> lg(violationMutex);
                            violationQueue.push(v);
                        }
                        violationCV.notify_one();
                        vehicles[i].challanIssued = true; // Mark challan as issued
                        std::cout << "Challan issued to " << vehicles[i].numberPlate << " at " << v.dateTime << "\n";
                    }
                } else {
                    // Reset the challan flag and time over limit if speed is back within limit
                    vehicles[i].timeOverLimit = 0.0f;
                    vehicles[i].challanIssued = false;
                }
            }
        }
        handleOutOfBoundsAndShift(vehicles, MAX_VEHICLES, vehicleTextures, LANE_X1, LANE_X2);

        // if (emergencyVehicleTimer2.getElapsedTime().asSeconds() >= 15.0f) {
        //     emergencyVehicleTimer2.restart(); // Reset the timer

        //     // 20% chance to spawn an emergency vehicle
        //     if (distribution(generator) <= 20) { // 20% probability for north to south
        //         for (int i = 0; i < MAX_VEHICLES; ++i) {
        //             if (northSouthVehicles[i].type != Emergency) { // Find a non-emergency vehicle
        //                 northSouthVehicles[i].type = Emergency; // Convert to emergency
        //                 northSouthVehicles[i].maxSpeed = 80.0f / 3.6f; // Set max speed to 80 km/h in m/s
        //                 northSouthVehicles[i].speed = northSouthVehicles[i].maxSpeed * 0.6f; // Initial speed at 80% of max
        //                 northSouthVehicles[i].sprite.setTexture(vehicleTextures[4]); // Assign emergency texture
        //                 std::cout << "Emergency vehicle spawned (North to South) at index: " << i << std::endl;
        //                 break;
        //             }
        //         }
        //     }
        // }

        // Update Vehicles North to South
        randomlyBreakdownVehicles_1(northSouthVehicles, MAX_VEHICLES);
        for (int i = 0; i < MAX_VEHICLES; ++i) {
            checkHeavyVehicleDuringPeak(simulationTime, northSouthVehicles[i]);
            bool canMove1 = true;

            // Handle out-of-order vehicles
            if (northSouthVehicles[i].outOfOrder) {
                northSouthVehicles[i].sprite.setColor(sf::Color::Red);
                canMove1 = false;
                northSouthVehicles[i].breakdownTimer++;
                if (northSouthVehicles[i].breakdownTimer > 300) {
                    northSouthVehicles[i].outOfOrder = false;
                    northSouthVehicles[i].sprite.setColor(sf::Color::White);
                    northSouthVehicles[i].breakdownTimer = 0;
                }
            }

            // Junction logic
            if (!isGreenNS && northSouthVehicles[i].position.y < JUNCTION_Y_1) {
                canMove1 = false;
            }

            // Reduce speed after leaving the junction
            if (northSouthVehicles[i].position.y < JUNCTION_Y_1 - 30) {
                northSouthVehicles[i].speed = std::max(northSouthVehicles[i].speed - 0.01f, 0.5f);
            }

            //if (northSouthVehicles[i].type == Emergency) {
            //    for (int j = 0; j < MAX_VEHICLES; ++j) {
            //        if (i != j && northSouthVehicles[j].lane == northSouthVehicles[i].lane && northSouthVehicles[j].position.y < northSouthVehicles[i].position.y) {
            //            // Speed up the vehicle in front
            //            northSouthVehicles[j].speed = std::min(northSouthVehicles[j].speed + 0.4f, northSouthVehicles[j].maxSpeed * 1.5f); // Temporary boost
            //            northSouthVehicles[i].speed = std::min(northSouthVehicles[i].speed + 0.4f, northSouthVehicles[i].maxSpeed * 1.5f); // Emergency speed boost
            //        }
            //    }
            //}

            // Maintain safe distance from other vehicles
            for (int j = 0; j < MAX_VEHICLES; ++j) {
                if (i != j && northSouthVehicles[i].lane == northSouthVehicles[j].lane) {
                    if (northSouthVehicles[i].position.y < northSouthVehicles[j].position.y &&
                        northSouthVehicles[j].position.y - northSouthVehicles[i].position.y < VEHICLE_SPACING) {
                        canMove1 = false;
                        break;
                    }
                }
            }

            if (int(simulationTime) % 50 == 0) {  // Every 5 seconds
                if (rand() % 2 == 0) {  // Randomly pick some vehicles (50% chance)
                    if (northSouthVehicles[i].speed + 0.6f <= northSouthVehicles[i].maxSpeed) {
                        northSouthVehicles[i].speed += 0.6f;  // Increase speed by 0.5 km/h or 5 km/h
                    }
                }
                
            }

            // Allow vehicles to move if conditions are met
            if (canMove1) {
                northSouthVehicles[i].position.y += northSouthVehicles[i].speed;
            }
            northSouthVehicles[i].sprite.setPosition(northSouthVehicles[i].position);

            // Speed limit violation check
            if (simulationTime > 300) { // For testing, you can reduce this number
                if (northSouthVehicles[i].speed > SPEED_LIMIT) {
                    northSouthVehicles[i].timeOverLimit += 1.0f; // Assuming each frame represents 1 second
                    if (northSouthVehicles[i].timeOverLimit >= 2.0f && !northSouthVehicles[i].challanIssued) { // 5-second threshold
                        // Create Violation with current mock date-time
                        Violation v;
                        v.plate = northSouthVehicles[i].numberPlate;
                        v.speed = northSouthVehicles[i].speed;
                        v.dateTime = getMockDateTimeString(mockTime);
                         v.vehicleType= northSouthVehicles[i].typestr;
                         v.dir= northSouthVehicles[i].direction;


                        {
                            std::lock_guard<std::mutex> lg(violationMutex);
                            violationQueue.push(v);
                        }
                        violationCV.notify_one();
                        northSouthVehicles[i].challanIssued = true; // Mark challan as issued
                        std::cout << "Challan issued to " << northSouthVehicles[i].numberPlate << " at " << v.dateTime <<  v.vehicleType << "\n";
                    }
                } else {
                    // Reset the challan flag and time over limit if speed is back within limit
                    northSouthVehicles[i].timeOverLimit = 0.0f;
                    northSouthVehicles[i].challanIssued = false;
                }
            }
        }
        handleOutOfBoundsAndShift_northSouth(northSouthVehicles, MAX_VEHICLES, vehicleTextures, LANE_X3, LANE_X4);


        // Update Vehicles East to West
        randomlyBreakdownVehicles_2(eastWestVehicles, MAX_VEHICLES);
        for (int i = 0; i < MAX_VEHICLES; ++i) {
            checkHeavyVehicleDuringPeak(simulationTime, eastWestVehicles[i]);
            bool canMove2 = true;

            // Handle out-of-order vehicles
            if (eastWestVehicles[i].outOfOrder) {
                eastWestVehicles[i].sprite.setColor(sf::Color::Red);
                canMove2 = false;
                eastWestVehicles[i].breakdownTimer++;
                if (eastWestVehicles[i].breakdownTimer > 300) {
                    eastWestVehicles[i].outOfOrder = false;
                    eastWestVehicles[i].sprite.setColor(sf::Color::White);
                    eastWestVehicles[i].breakdownTimer = 0;
                }
            }

            // Junction logic
            if (!isGreenEW && eastWestVehicles[i].position.x > JUNCTION_X) {
                canMove2 = false;
            }

            // Reduce speed after leaving the junction
           if (eastWestVehicles[i].position.x > JUNCTION_X + 30) {
                eastWestVehicles[i].speed = std::max(eastWestVehicles[i].speed - 0.01f, 0.4f);
            }

            //if (eastWestVehicles[i].type == Emergency) 
            //{
            //    for (int j = 0; j < MAX_VEHICLES; ++j) {
            //        if (i != j && eastWestVehicles[j].lane == eastWestVehicles[i].lane && eastWestVehicles[j].position.x > eastWestVehicles[i].position.x) {
            //            // Speed up the vehicle in front
            //            eastWestVehicles[j].speed = std::min(eastWestVehicles[j].speed + 0.4f, eastWestVehicles[j].maxSpeed * 1.5f); // Temporary boost
            //            eastWestVehicles[i].speed = std::min(eastWestVehicles[i].speed + 0.4f, eastWestVehicles[i].maxSpeed * 1.5f); // Emergency speed boost
            //        }
            //    }
            //}

            // Maintain safe distance from other vehicles
            for (int j = 0; j < MAX_VEHICLES; ++j) {
                if (i != j && eastWestVehicles[i].lane == eastWestVehicles[j].lane) {
                    if (eastWestVehicles[i].position.x > eastWestVehicles[j].position.x &&
                        eastWestVehicles[i].position.x - eastWestVehicles[j].position.x < VEHICLE_SPACING) {
                        canMove2 = false;
                        break;
                    }
                }
            }

            if (int(simulationTime) % 50 == 0) {  // Every 5 seconds
                if (rand() % 2 == 0) {  // Randomly pick some vehicles (50% chance)
                    if (eastWestVehicles[i].speed + 0.6f <= eastWestVehicles[i].maxSpeed) {
                        eastWestVehicles[i].speed += 0.6f;  // Increase speed by 0.5 km/h or 5 km/h
                    }
                }
                
            }

            // Allow vehicles to move if conditions are met
            if (canMove2) {
                eastWestVehicles[i].position.x -= eastWestVehicles[i].speed;
            }
            eastWestVehicles[i].sprite.setPosition(eastWestVehicles[i].position);

            // Speed limit violation check
            if (simulationTime > 300) { // For testing, you can reduce this number
                if (eastWestVehicles[i].speed > SPEED_LIMIT) {
                    eastWestVehicles[i].timeOverLimit += 1.0f; // Assuming each frame represents 1 second
                    if (eastWestVehicles[i].timeOverLimit >= 2.0f && !eastWestVehicles[i].challanIssued) { // 5-second threshold
                        // Create Violation with current mock date-time
                        Violation v;
                        v.plate = eastWestVehicles[i].numberPlate;
                       
                        v.speed = eastWestVehicles[i].speed;
                        v.dateTime = getMockDateTimeString(mockTime);
                         v.vehicleType= eastWestVehicles[i].typestr;
                         v.dir= eastWestVehicles[i].direction;


                        {
                            std::lock_guard<std::mutex> lg(violationMutex);
                            violationQueue.push(v);
                        }
                        violationCV.notify_one();
                        eastWestVehicles[i].challanIssued = true; // Mark challan as issued
                        std::cout << "Challan issued to " << v.plate << " at " << v.dateTime << v.vehicleType << "\n";
                    }
                } else {
                    // Reset the challan flag and time over limit if speed is back within limit
                    eastWestVehicles[i].timeOverLimit = 0.0f;
                    eastWestVehicles[i].challanIssued = false;
                }
            }
        }
        handleOutOfBoundsAndShiftEastWest(eastWestVehicles, MAX_VEHICLES, vehicleTextures_1, LANE_X5, LANE_X6);


        // Update Vehicles West to East
        randomlyBreakdownVehicles_3(WestEastVehicles, MAX_VEHICLES);
        for (int i = 0; i < MAX_VEHICLES; ++i) {
            checkHeavyVehicleDuringPeak(simulationTime, WestEastVehicles[i]);
            bool canMove3 = true;

            // Handle out-of-order vehicles
            if (WestEastVehicles[i].outOfOrder) {
                WestEastVehicles[i].sprite.setColor(sf::Color::Red);
                canMove3 = false;
                WestEastVehicles[i].breakdownTimer++;
                if (WestEastVehicles[i].breakdownTimer > 100) {
                    WestEastVehicles[i].outOfOrder = false;
                    WestEastVehicles[i].sprite.setColor(sf::Color::White);
                    WestEastVehicles[i].breakdownTimer = 0;
                }
            }

            // Junction logic
            if (!isGreenWE && WestEastVehicles[i].position.x < JUNCTION_X_1) {
                canMove3 = false;
            }

            // Reduce speed after leaving the junction
            if (WestEastVehicles[i].position.x < JUNCTION_X_1 - 30) { // Adjust based on your junction size
                WestEastVehicles[i].speed = std::max(WestEastVehicles[i].speed - 0.01f, 0.4f); // Gradually reduce speed
            }

            //if (WestEastVehicles[i].type == Emergency) 
            //{
            //    for (int j = 0; j < MAX_VEHICLES; ++j) 
            //    {
            //        if (i != j && WestEastVehicles[j].lane == WestEastVehicles[i].lane && WestEastVehicles[j].position.x < WestEastVehicles[i].position.x) {
            //            // Speed up the vehicle in front
            //            WestEastVehicles[j].speed = std::min(WestEastVehicles[j].speed + 0.4f, WestEastVehicles[j].maxSpeed * 1.5f); // Temporary boost
            //            WestEastVehicles[i].speed = std::min(WestEastVehicles[i].speed + 0.4f, WestEastVehicles[i].maxSpeed * 1.5f); // Emergency speed boost
            //        }
            //    }
            //}


            // Maintain safe distance from other vehicles
            for (int j = 0; j < MAX_VEHICLES; ++j) {
                if (i != j && WestEastVehicles[i].lane == WestEastVehicles[j].lane) {
                    if (WestEastVehicles[i].position.x > WestEastVehicles[j].position.x &&
                        WestEastVehicles[i].position.x - WestEastVehicles[j].position.x < VEHICLE_SPACING) {
                        canMove3 = false;
                        break;
                    }
                }
            }

            if (int(simulationTime) % 50 == 0) {  // Every 5 seconds
                if (rand() % 2 == 0) {  // Randomly pick some vehicles (50% chance)
                    if (WestEastVehicles[i].speed + 0.6f <= WestEastVehicles[i].maxSpeed) {
                        WestEastVehicles[i].speed += 0.6f;  // Increase speed by 0.5 km/h or 5 km/h
                    }
                }
                
            }

            // Allow vehicles to move if conditions are met
            if (canMove3) {
                WestEastVehicles[i].position.x += WestEastVehicles[i].speed;
            }
            WestEastVehicles[i].sprite.setPosition(WestEastVehicles[i].position);

            // Speed limit violation check
            if (simulationTime > 300) { // For testing, you can reduce this number
                if (WestEastVehicles[i].speed > SPEED_LIMIT) {
                    WestEastVehicles[i].timeOverLimit += 1.0f; // Assuming each frame represents 1 second
                    if (WestEastVehicles[i].timeOverLimit >= 2.0f && !WestEastVehicles[i].challanIssued) { // 5-second threshold
                        // Create Violation with current mock date-time
                        Violation v;
                        v.plate = WestEastVehicles[i].numberPlate;
                    
                        v.speed = WestEastVehicles[i].speed;
                        v.dateTime = getMockDateTimeString(mockTime);
                         v.vehicleType= WestEastVehicles[i].typestr;
                         v.dir= WestEastVehicles[i].direction;


                        {
                            std::lock_guard<std::mutex> lg(violationMutex);
                            violationQueue.push(v);
                        }
                        violationCV.notify_one();
                        WestEastVehicles[i].challanIssued = true; // Mark challan as issued
                        std::cout << "Challan issued to " << v.plate << " at " << v.dateTime << v.vehicleType << "\n";
                    }
                } else {
                    // Reset the challan flag and time over limit if speed is back within limit
                    WestEastVehicles[i].timeOverLimit = 0.0f;
                    WestEastVehicles[i].challanIssued = false;
                }
            }
        }
        handleOutOfBoundsAndShiftWestEast(WestEastVehicles, MAX_VEHICLES, vehicleTextures_1, LANE_X7, LANE_X8);


        // Maintain spacing
        maintainSpacing(vehicles, MAX_VEHICLES, VEHICLE_SPACING);
        maintainSpacingNorthSouth(northSouthVehicles, MAX_VEHICLES, VEHICLE_SPACING);
        maintainSpacingEastWest(eastWestVehicles, MAX_VEHICLES, VEHICLE_SPACING);
        maintainSpacingWestEast(WestEastVehicles, MAX_VEHICLES, VEHICLE_SPACING);

        // Render
        window.clear();
        window.draw(backgroundSprite);

        // Draw traffic lights based on current state
       // Draw traffic lights based on current state
// N-S lights
if (isRedNS) window.draw(trafficLight_red_ns);
if (isYellowNS) window.draw(trafficLight_yellow_ns);
if (isGreenNS) window.draw(trafficLight_green_ns);

// S-N lights
if (isRedSN) window.draw(trafficLight_red_sn);
if (isYellowSN) window.draw(trafficLight_yellow_sn);
if (isGreenSN) window.draw(trafficLight_green_sn);

// W-E lights
if (isRedWE) window.draw(trafficLight_red_we);
if (isYellowWE) window.draw(trafficLight_yellow_we);
if (isGreenWE) window.draw(trafficLight_green_we);

// E-W lights
if (isRedEW) window.draw(trafficLight_red_ew);
if (isYellowEW) window.draw(trafficLight_yellow_ew);
if (isGreenEW) window.draw(trafficLight_green_ew);

        // Draw all vehicles
        for (int i = 0; i < MAX_VEHICLES; ++i) {
            window.draw(vehicles[i].sprite);
        }

        for (int i = 0; i < MAX_VEHICLES; ++i) {
            window.draw(northSouthVehicles[i].sprite);
        }

        for (int i = 0; i < MAX_VEHICLES; ++i) {
            window.draw(eastWestVehicles[i].sprite);
        }

        for (int i = 0; i < MAX_VEHICLES; ++i) {
            window.draw(WestEastVehicles[i].sprite);
        }

        // Draw clock
        window.draw(clockText);

        window.display();
    }

      vehicleCountWriter.join();

    return 0;
}
